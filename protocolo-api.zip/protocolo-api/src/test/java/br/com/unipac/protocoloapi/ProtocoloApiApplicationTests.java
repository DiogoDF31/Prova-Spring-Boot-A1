package br.com.unipac.protocoloapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProtocoloApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
